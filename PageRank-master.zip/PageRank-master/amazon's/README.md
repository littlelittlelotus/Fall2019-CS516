the code version for AWS
